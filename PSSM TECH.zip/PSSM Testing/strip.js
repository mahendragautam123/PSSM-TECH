$(document).ready(function () {
    let isAlerted = localStorage.getItem("alerted_check");
    if (!isAlerted) $("div.headerstrip-wrapper").fadeIn("7000");
  });
  
  var closeButtons = $(".js-banner__dismiss");
  closeButtons.on("click", function () {
    $(this).parent().hide();
    localStorage.setItem("alerted_check", "yes");
  });
  